package WhackAMole;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Random;

 class WhackAMole implements ActionListener {
    int boardWidth = 600;
    int boardHeight = 650;

    JFrame frame = new JFrame("Mario: Whack a Mole!");

    JPanel textpanel = new JPanel();
    JPanel boardpanel = new JPanel();

    JLabel textlabel = new JLabel();

    JButton board[] = new JButton[9];

    ImageIcon moleIcon;
    ImageIcon plantIcon;

     Random random = new Random();

    int plantPosition;
    int pp;
    int molePosition;
    int mp;
    int score=0;
    boolean gameOver = false;
    String scoremsg;

    WhackAMole()  {
        setupBoard();
        setupMoleAndPlant();
        pickSpotForMoleAndPlant();

        try {
            Thread.sleep(1000);
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }
//        restart();
    }

    void setupBoard(){
        frame.setSize(boardWidth, boardHeight);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLocationRelativeTo(null);
        frame.setResizable(false);
        frame.setLayout(new BorderLayout());

        textlabel.setFont(new Font("Consolas", Font.PLAIN, 25 ) );//Setting font size and style
        textlabel.setHorizontalAlignment(JLabel.CENTER);
        textlabel.setText("Score: 0");
        textlabel.setOpaque(true);

        textpanel.setLayout(new BorderLayout());
        textpanel.add(textlabel);

        boardpanel.setLayout(new GridLayout(3,3));//Makes a grid of three rows and three columns
        frame.add(boardpanel);
        frame.add(textpanel, BorderLayout.NORTH);
    }
    void setupMoleAndPlant(){
        plantIcon = new ImageIcon(getClass().getResource("/WhackAMole/Piranha_plant.png"));//This line creates a new ImageIcon object
        // from an image file located at the specified path (./Piranha_plant.png). The method getClass().getResource is used to
        // find the resource (image file) relative to the class's location in the file system or JAR archive.

        Image plantImage = plantIcon.getImage();//This line extracts the Image object from the previously created ImageIcon object.
        // The getImage() method returns the Image contained in the ImageIcon.

        plantIcon= new ImageIcon(plantImage.getScaledInstance(170, 170, Image.SCALE_SMOOTH));//This line scales the extracted
        // image to the specified dimensions (170x170 pixels) using smooth scaling. The getScaledInstance method is used for this purpose.
        // The scaled image is then wrapped in a new ImageIcon object, which replaces the original plantIcon.

        //Bringing monty mole into the grid same way as piranhaPlant
        moleIcon = new ImageIcon(getClass().getResource("/WhackAMole/MontyMole.jpg"));
        Image moleImage = moleIcon.getImage();
        moleIcon = new ImageIcon(moleImage.getScaledInstance(170, 170, Image.SCALE_SMOOTH));

        for (int i = 0; i < 9; i++) {
            JButton tile = new JButton();
            board[i] = tile;//Making each grid box a clickable button
//            board[i].addActionListener(this);
            boardpanel.add(board[i]);
        }
    }

    void pickSpotForMoleAndPlant(){
        frame.setVisible(true);
        //Picking spot for mole
        molePosition= random.nextInt(9);

         mp = molePosition;//making a copy

        //Picking spot for plant
        do{
            plantPosition= random.nextInt(9);
        }while (plantPosition == molePosition);

         pp = plantPosition;//making a copy

        changeMoleAndPlant();
    }

    void changeMoleAndPlant(){
        do {
            //Setting mole and plant
            board[molePosition].setIcon(moleIcon);
            board[plantPosition].setIcon(plantIcon);

            board[molePosition].addActionListener(this);
            board[plantPosition].addActionListener(this);
            try {
                Thread.sleep(750);
            } catch (InterruptedException e) {
                throw new RuntimeException(e);
            }


            molePosition = random.nextInt(9);
            if (molePosition == mp){
                if(mp==0){
                    molePosition=mp+1;
                } else if (mp==8) {
                    molePosition=mp-1;
                }
                else{
                    molePosition+=1;
                }
            }

            {do{
                plantPosition= random.nextInt(9);
            }while (plantPosition == molePosition);}

            if (plantPosition == pp){
                if(pp==0){
                    plantPosition=pp+1;
                } else if (pp==8) {
                    plantPosition=pp-1;
                }
                else{
                    plantPosition+=1;
                }
            }
            board[molePosition].removeActionListener(this);
            board[plantPosition].removeActionListener(this);

            if(!gameOver){
                board[mp].setIcon(null);
                board[pp].setIcon(null);}

            mp= molePosition;
            pp=plantPosition;
        }while (!gameOver);
        try {
            Thread.sleep(5000);
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }
        restart();
    }

    void restart(){
        score = 0;
        gameOver = false;
        textlabel.setText("Score: 0");

        // Clear all icons and remove action listeners
        for (int i = 0; i < 9; i++) {
            board[i].setIcon(null);
            board[i].removeActionListener(this);
        }
        changeMoleAndPlant();
    }


    @Override
    public void actionPerformed(ActionEvent e) {
        if(e.getSource() == board[molePosition]){
            gameOver= false;
            score+=10;
            textlabel.setText("Score: "+score);
        }
        if(e.getSource() == board[plantPosition]) {
            gameOver = true;
            textlabel.setText("Game Over, Points: " + score);
        }
    }
}

public class App_WhackAMole {
    public static void main(String[] args) {
        WhackAMole whackAMole= new WhackAMole();
    }
}
